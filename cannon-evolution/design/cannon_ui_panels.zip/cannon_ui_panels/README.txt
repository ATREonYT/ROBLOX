CANNON GAME UI — REBUILT PANELS

Six complete transparent PNG panels: Shop, Cannons, Cannon Balls, Rebirth, Worlds and Upgrades.
All six are newly recreated artwork, NOT exact screenshot crops.
Generated with the built-in image-generation tool. Prompts and dimensions are in manifest.json.

All image pixels are preserved, with 64 pixels of additional transparent margin on each side.
Rebirth uses exactly two curved arrows.

These are flattened visual assets. Text and buttons are baked in.
For functional Roblox UI, layer interactive controls over the artwork or implement separate UI elements.
