CARTOON CANNON BALL UI ICONS

24 individual 1024 x 1024 transparent PNGs. At least 96 px clear padding on all sides.
Artwork is newly recreated using built-in image_gen, not exact crops or original model renders.
Designs follow the supplied Cannon Balls.png. Front-facing composition, with the rocket upright.
Source rarity and row/column identifiers are in manifest.json, along with all generation prompts.
Use the individual PNG files for Roblox UI images. Preview background is for viewing only.
