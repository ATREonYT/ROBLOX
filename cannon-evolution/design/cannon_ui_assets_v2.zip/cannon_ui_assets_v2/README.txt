CANNON UI ASSETS v2

15 newly recreated high-resolution transparent icons, each 1024 x 1024.
Gift has NO number and NO notification badge. Rebirth has TWO arrows.
All standalone icons have at least 64 pixels of clear margin.

74 source-based UI exports included with extra padding and 2x resampling.
These panels, cards and controls retain their original contents and source resolution limitations.
Recreated artwork is NOT an exact crop. See manifest.json for provenance and generation prompts.
