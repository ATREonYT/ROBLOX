FRONT-FACING CARTOON EGGS AND PETS — UI PNG PACK

All assets use a front-facing view with level eyes and slight top visibility.
45 pets + 9 eggs, individually exported at 1024 x 1024 with transparent backgrounds.
Each has at least 96 px clear margin on all sides. Egg bases are retained.

IDENTIFICATION
pet_rN_cN uses the original screenshot: row top-to-bottom, column left-to-right, excluding eggs.
egg_01 through egg_09 run top-to-bottom down the egg column.
Names are visual descriptions, not official in-game names.

All assets were reoriented from the previous cartoon PNGs using the built-in image-generation tool.
They are not exact cropped artwork. Designs follow the screenshot; hidden details may be inferred.
See manifest.json for all reference positions, descriptions and generation prompts.
