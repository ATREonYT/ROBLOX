Eight transparent PNGs matching the visible requested symbols.
The star, shirt, equipped check and sneaker were redrawn as clean geometric shapes at 1024 x 1024.
The three visible tier crowns and XP badge are the existing 1254 x 1254 high-resolution recreations.
The red crown is identified from the partial SUB5 crown at the bottom of screenshot 4.
No button backgrounds or UI text are included. Use aspect-preserving Fit in the UI.
