Five transparent PNGs for the quest UI screenshot.
Newly redrawn: tag-fist, stopwatch, players (1024 x 1024).
Included existing sharp assets: sneaker (1024 x 1024), xp-badge (1254 x 1254).
The players icon matches the three-person symbol shown in the new screenshot.
No card backgrounds, quest text, or progress bars included. Keep image proportions when placing in the UI.
